// Cambiar el patrón de fondo
function changePattern(patternClass) {
    const currentMode = document.body.classList.contains('dark-mode') ? 'dark-mode' : 'light-mode';
    document.body.className = `${patternClass} ${currentMode}`;
}

// Alternar modo oscuro/claro
function toggleDarkMode() {
    const isDarkMode = document.body.classList.toggle('dark-mode');
    const patterns = ['pattern-circles', 'pattern-lines', 'pattern-grid'];
    let currentPattern = patterns.find(pattern => document.body.classList.contains(pattern)) || 'pattern-circles';
    document.body.className = `${currentPattern} ${isDarkMode ? 'dark-mode' : 'light-mode'}`;

    // Cambiar estilos del panel de personalización en modo oscuro
    const panel = document.querySelector('.customization-panel');
    if (isDarkMode) {
        panel.style.background = "rgba(0, 0, 0, 0.8)";
        panel.style.color = "#fff";
        panel.style.borderColor = "#444";
    } else {
        panel.style.background = "rgba(255, 255, 255, 0.9)";
        panel.style.color = "#000";
        panel.style.borderColor = "#ddd";
    }
}

// Añadir evento para guardar notas editadas
function saveNoteAsText(noteContent) {
    const blob = new Blob([noteContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'nota.txt';
    a.click();
    URL.revokeObjectURL(url);
}

// Añadir interacción de guardar al hacer doble clic en una nota
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.note').forEach(note => {
        note.addEventListener('dblclick', () => {
            const noteContent = note.textContent.trim();
            saveNoteAsText(noteContent);
        });
    });
});

function assignRandomColors() {
    const notes = document.querySelectorAll('.note');
    notes.forEach(note => {
        const randomColor = `hsl(${Math.random() * 360}, 50%, 75%)`;
        note.style.backgroundColor = randomColor;
    });
}


function updateLoadingProgress(loaded, total) {
    const loadingDiv = document.getElementById('loading');
    loadingDiv.textContent = `Cargando notas... ${loaded}/${total}`;
    if (loaded === total) {
        loadingDiv.style.display = 'none';
        document.getElementById('articles-container').style.display = 'block';
    }
}

function applyTagFilter(tag, button) {
    const notes = document.querySelectorAll(`.note[data-tag="${tag}"]`);
    const isActive = button.getAttribute('aria-pressed') === 'true';
    notes.forEach(note => note.style.display = isActive ? 'none' : 'block');
    button.setAttribute('aria-pressed', !isActive);
}
